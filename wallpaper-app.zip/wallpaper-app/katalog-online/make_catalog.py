#!/usr/bin/env python3
"""Membuat thumbnail + catalog.json dari folder gambar.

Susunan folder (nama subfolder = kategori di aplikasi):
    wallpapers/Alam/pantai.jpg
    wallpapers/Gelap/malam.png

Pemakaian:
    pip install pillow
    python make_catalog.py --base-url https://raw.githubusercontent.com/USERNAME/REPO/main/

Hasil: folder thumbs/ dan file catalog.json. Unggah semuanya ke repo GitHub.
"""
import argparse
import json
import re
from pathlib import Path
from PIL import Image, ImageOps

EXT = {".jpg", ".jpeg", ".png", ".webp"}


def slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", required=True, help="alamat dasar repo, diakhiri /")
    ap.add_argument("--thumb-width", type=int, default=400)
    ap.add_argument("--max-side", type=int, default=2560, help="perkecil gambar penuh jika lebih besar (0 = jangan)")
    args = ap.parse_args()

    root = Path(__file__).parent
    base = args.base_url.rstrip("/") + "/"
    thumbs = root / "thumbs"
    thumbs.mkdir(exist_ok=True)

    items = []
    for path in sorted((root / "wallpapers").rglob("*")):
        if path.suffix.lower() not in EXT:
            continue
        rel = path.relative_to(root)
        category = path.parent.name if path.parent.name != "wallpapers" else "Online"
        wid = slug(f"{category}-{path.stem}")

        img = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
        if args.max_side and max(img.size) > args.max_side:
            full = img.copy()
            full.thumbnail((args.max_side, args.max_side))
            full.save(path.with_suffix(".jpg"), quality=90)
            if path.suffix.lower() != ".jpg":
                path.unlink()
                rel = rel.with_suffix(".jpg")
        thumb = img.copy()
        thumb.thumbnail((args.thumb_width, args.thumb_width * 3))
        thumb_name = f"{wid}.jpg"
        thumb.save(thumbs / thumb_name, quality=80)

        items.append({
            "id": wid,
            "name": path.stem.replace("_", " ").replace("-", " ").title(),
            "category": category,
            "thumb": f"{base}thumbs/{thumb_name}",
            "url": base + rel.as_posix().replace(" ", "%20"),
        })

    (root / "catalog.json").write_text(json.dumps(items, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"{len(items)} wallpaper -> catalog.json")


if __name__ == "__main__":
    main()
