# Katalog online WallpaperKu

Folder ini adalah isi repo GitHub untuk wallpaper online. Salin folder ini ke repo publik baru
(misalnya `wallpaperku-katalog`); aplikasi tidak memerlukannya di dalam proyek Android.

1. Taruh gambar di `wallpapers/<Kategori>/nama.jpg` (nama subfolder = kategori di aplikasi).
2. Jalankan:
   ```
   pip install pillow
   python make_catalog.py --base-url https://raw.githubusercontent.com/USERNAME/REPO/main/
   ```
   Skrip membuat `thumbs/` (gambar kecil untuk grid) dan `catalog.json`.
3. Commit & push semuanya (`wallpapers/`, `thumbs/`, `catalog.json`) ke branch `main`.
4. Di aplikasi, buka `Config.kt` dan isi `CATALOG_URL` dengan:
   `https://raw.githubusercontent.com/USERNAME/REPO/main/catalog.json`

Untuk menambah wallpaper berikutnya: taruh gambar baru, jalankan skrip lagi, push. Pengguna
langsung melihatnya saat membuka aplikasi (atau lewat menu ⋮ → Segarkan katalog online).

Catatan: GitHub menyarankan repo di bawah ~1 GB; gunakan JPEG (±300–800 KB per gambar).
Pakai hanya gambar yang Anda punya haknya, karena repo publik bisa diunduh siapa saja.
