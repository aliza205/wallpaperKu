package com.contoh.wallpaperku

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import android.view.View
import android.widget.Button
import androidx.core.content.ContextCompat
import kotlin.math.ceil
import kotlin.math.min

/**
 * Permukaan neumorphism: bentuk sewarna latar dengan dua bayangan lembut
 * (terang di kiri-atas, gelap di kanan-bawah). Mode [inset] = cekung (ditekan / terpilih).
 * Bayangan digambar ke bitmap sekali per ukuran, jadi ringan saat scroll.
 * Ruang bayangan sudah termasuk di dalam batas view (lihat [Neu.marginPx]).
 */
class NeuDrawable(
    ctx: Context,
    private val radiusDp: Int,
    private val inset: Boolean,
    private val scale: Float,
    private val fill: Int?,
    private val circle: Boolean
) : Drawable() {

    private val density = ctx.resources.displayMetrics.density
    private val bg = ContextCompat.getColor(ctx, R.color.neu_bg)
    private val light = ContextCompat.getColor(ctx, R.color.neu_light)
    private val dark = ContextCompat.getColor(ctx, R.color.neu_dark)

    private val depth = Neu.DEPTH_DP * density * scale
    private val blur = Neu.BLUR_DP * density * scale
    private val margin = depth + blur

    private var cache: Bitmap? = null

    override fun onBoundsChange(bounds: Rect) {
        cache = null
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.width() <= 0 || b.height() <= 0) return
        var bmp = cache
        if (bmp == null) {
            bmp = build(b.width(), b.height())
            cache = bmp
        }
        canvas.drawBitmap(bmp, b.left.toFloat(), b.top.toFloat(), null)
    }

    private fun build(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rect = RectF(margin, margin, w - margin, h - margin)
        if (rect.width() <= 0f || rect.height() <= 0f) return bmp

        val maxR = min(rect.width(), rect.height()) / 2f
        val r = if (circle) maxR else min(radiusDp * density, maxR)

        val surface = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fill ?: bg }
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            maskFilter = BlurMaskFilter(blur, BlurMaskFilter.Blur.NORMAL)
        }

        if (!inset) {
            // Timbul: bayangan gelap ke kanan-bawah, terang ke kiri-atas
            shadow.color = dark
            c.save(); c.translate(depth, depth); c.drawRoundRect(rect, r, r, shadow); c.restore()
            shadow.color = light
            c.save(); c.translate(-depth, -depth); c.drawRoundRect(rect, r, r, shadow); c.restore()
            c.drawRoundRect(rect, r, r, surface)
        } else {
            // Cekung: bayangan di sisi dalam, dipotong mengikuti bentuk
            c.drawRoundRect(rect, r, r, surface)
            val frame = Path().apply {
                fillType = Path.FillType.EVEN_ODD
                addRect(-w.toFloat(), -h.toFloat(), 2f * w, 2f * h, Path.Direction.CW)
                addRoundRect(rect, r, r, Path.Direction.CW)
            }
            val layer = c.saveLayer(0f, 0f, w.toFloat(), h.toFloat(), null)
            shadow.color = dark
            c.save(); c.translate(depth, depth); c.drawPath(frame, shadow); c.restore()
            shadow.color = light
            c.save(); c.translate(-depth, -depth); c.drawPath(frame, shadow); c.restore()
            val mask = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            }
            c.drawRoundRect(rect, r, r, mask)
            c.restoreToCount(layer)
        }
        return bmp
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Pembantu untuk memasang gaya neumorphism ke view. */
object Neu {
    const val DEPTH_DP = 4f
    const val BLUR_DP = 7f

    /** Ruang di sekeliling bentuk yang dipakai bayangan (px). */
    fun marginPx(v: View, scale: Float): Int =
        ceil((DEPTH_DP + BLUR_DP) * v.resources.displayMetrics.density * scale).toInt()

    /** Tambah padding sebesar ruang bayangan; aman dipanggil berulang pada view yang sama. */
    private fun applyPadding(v: View, m: Int) {
        @Suppress("UNCHECKED_CAST")
        val base = (v.getTag(R.id.neu_pad) as? IntArray)
            ?: intArrayOf(v.paddingLeft, v.paddingTop, v.paddingRight, v.paddingBottom)
                .also { v.setTag(R.id.neu_pad, it) }
        v.setPadding(base[0] + m, base[1] + m, base[2] + m, base[3] + m)
    }

    /** Tentukan padding asli (di luar ruang bayangan) sebelum memanggil raised/inset/pressable. */
    fun basePadding(v: View, l: Int, t: Int, r: Int, b: Int) {
        v.setTag(R.id.neu_pad, intArrayOf(l, t, r, b))
    }

    fun raised(v: View, radiusDp: Int, scale: Float = 1f, fill: Int? = null, circle: Boolean = false) {
        v.background = NeuDrawable(v.context, radiusDp, false, scale, fill, circle)
        applyPadding(v, marginPx(v, scale))
    }

    fun inset(v: View, radiusDp: Int, scale: Float = 1f, circle: Boolean = false) {
        v.background = NeuDrawable(v.context, radiusDp, true, scale, null, circle)
        applyPadding(v, marginPx(v, scale))
    }

    /** Timbul biasanya; cekung saat ditekan atau terpilih (selected). */
    fun pressable(v: View, radiusDp: Int, scale: Float = 1f, fill: Int? = null, circle: Boolean = false) {
        val states = StateListDrawable()
        val sunken = NeuDrawable(v.context, radiusDp, true, scale, fill, circle)
        states.addState(intArrayOf(android.R.attr.state_pressed), sunken)
        states.addState(
            intArrayOf(android.R.attr.state_selected),
            NeuDrawable(v.context, radiusDp, true, scale, fill, circle)
        )
        states.addState(intArrayOf(), NeuDrawable(v.context, radiusDp, false, scale, fill, circle))
        v.background = states
        applyPadding(v, marginPx(v, scale))
    }

    fun button(b: Button, radiusDp: Int = 18, accent: Boolean = false, fill: Int? = null) {
        val ctx = b.context
        b.isAllCaps = false
        b.stateListAnimator = null
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(ContextCompat.getColor(ctx, if (accent) R.color.neu_accent else R.color.neu_text))
        val m = marginPx(b, 0.8f)
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = ctx.dp(44) + 2 * m
        b.minimumHeight = ctx.dp(44) + 2 * m
        basePadding(b, ctx.dp(10), ctx.dp(4), ctx.dp(10), ctx.dp(4))
        pressable(b, radiusDp, 0.8f, fill)
    }
}
