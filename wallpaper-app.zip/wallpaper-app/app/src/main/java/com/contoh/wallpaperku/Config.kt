package com.contoh.wallpaperku

object Config {
    /**
     * Alamat file katalog online (catalog.json). GANTI dengan alamat milik Anda,
     * misalnya file di repo GitHub publik:
     * https://raw.githubusercontent.com/aloza205/wallpaper-ink/main/Man_mosaic_vector_illustration_p…_2c4bbfa5_2K.jpg
     * Selama masih berisi "USERNAME", fitur online dimatikan.
     */
    const val CATALOG_URL = "https://raw.githubusercontent.com/aliza205/wallpaper-ink/main/Man_mosaic_vector_illustration_p…_2c4bbfa5_2K.jpg"

    val isConfigured: Boolean get() = !CATALOG_URL.contains("USERNAME")
}
