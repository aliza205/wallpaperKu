package com.contoh.wallpaperku

object Config {
    /**
     * Alamat file katalog online (catalog.json). GANTI dengan alamat milik Anda,
     * misalnya file di repo GitHub publik:
     * https://raw.githubusercontent.com/USERNAME/REPO/main/catalog.json
     * Selama masih berisi "USERNAME", fitur online dimatikan.
     */
    const val CATALOG_URL = "Man_mosaic_vector_illustration_p…_2c4bbfa5_2K.jpg/main/catalog.json"

    val isConfigured: Boolean get() = !CATALOG_URL.contains("USERNAME")
}
