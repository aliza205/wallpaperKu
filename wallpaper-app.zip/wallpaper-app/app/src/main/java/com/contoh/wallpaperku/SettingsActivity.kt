package com.contoh.wallpaperku

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

/** Pengaturan: tema, jumlah kolom, dan ganti wallpaper otomatis. */
class SettingsActivity : AppCompatActivity() {

    private val intervalHours = listOf(1, 3, 6, 12, 24)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        setupHeader("Pengaturan")

        // Tampilan neumorphism: kartu timbul, pemilih cekung, tombol timbul
        Neu.raised(findViewById(R.id.cardAppearance), 26)
        Neu.raised(findViewById(R.id.cardAuto), 26)
        Neu.inset(findViewById(R.id.spWrap), 16, 0.7f)
        Neu.button(findViewById(R.id.btnNow), 20, accent = true)

        // ----- Tema -----
        val rgTheme = findViewById<RadioGroup>(R.id.rgTheme)
        rgTheme.check(
            when (Prefs.themeMode(this)) {
                1 -> R.id.rbThemeLight
                2 -> R.id.rbThemeDark
                else -> R.id.rbThemeSystem
            }
        )
        rgTheme.setOnCheckedChangeListener { _, id ->
            val mode = when (id) {
                R.id.rbThemeLight -> 1
                R.id.rbThemeDark -> 2
                else -> 0
            }
            if (mode != Prefs.themeMode(this)) {
                Prefs.setThemeMode(this, mode)
                Prefs.applyTheme(this) // activity dibuat ulang otomatis
            }
        }

        // ----- Kolom -----
        val rgCols = findViewById<RadioGroup>(R.id.rgColumns)
        rgCols.check(if (Prefs.columns(this) == 3) R.id.rbCol3 else R.id.rbCol2)
        rgCols.setOnCheckedChangeListener { _, id ->
            Prefs.setColumns(this, if (id == R.id.rbCol3) 3 else 2)
        }

        // ----- Ganti otomatis -----
        val swAuto = findViewById<SwitchCompat>(R.id.swAuto)
        swAuto.isChecked = Prefs.autoEnabled(this)
        swAuto.setOnCheckedChangeListener { _, checked ->
            Prefs.setAutoEnabled(this, checked)
            AutoChange.update(this)
        }

        val spInterval = findViewById<Spinner>(R.id.spInterval)
        val labels = intervalHours.map { if (it == 24) "Setiap hari" else "Setiap $it jam" }
        spInterval.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spInterval.setSelection(intervalHours.indexOf(Prefs.intervalHours(this)).coerceAtLeast(0))
        spInterval.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val hours = intervalHours[pos]
                if (hours != Prefs.intervalHours(this@SettingsActivity)) {
                    Prefs.setIntervalHours(this@SettingsActivity, hours)
                    AutoChange.update(this@SettingsActivity)
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        val rgTarget = findViewById<RadioGroup>(R.id.rgTarget)
        rgTarget.check(
            when (Prefs.autoTarget(this)) {
                0 -> R.id.rbTargetHome
                1 -> R.id.rbTargetLock
                else -> R.id.rbTargetBoth
            }
        )
        rgTarget.setOnCheckedChangeListener { _, id ->
            Prefs.setAutoTarget(
                this,
                when (id) {
                    R.id.rbTargetHome -> 0
                    R.id.rbTargetLock -> 1
                    else -> 2
                }
            )
        }

        val rgSource = findViewById<RadioGroup>(R.id.rgSource)
        rgSource.check(if (Prefs.autoSource(this) == 1) R.id.rbSrcFav else R.id.rbSrcAll)
        rgSource.setOnCheckedChangeListener { _, id ->
            Prefs.setAutoSource(this, if (id == R.id.rbSrcFav) 1 else 0)
        }

        findViewById<Button>(R.id.btnNow).setOnClickListener {
            Thread {
                val ok = AutoChange.changeNow(applicationContext)
                runOnUiThread {
                    if (isDestroyed) return@runOnUiThread
                    Toast.makeText(
                        this,
                        if (ok) "Wallpaper diganti" else "Tidak ada wallpaper yang bisa dipilih",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }.start()
        }
    }
}
