package com.contoh.wallpaperku

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Katalog wallpaper online: daftar (catalog.json) diambil dari internet dan disimpan di HP. */
object RemoteCatalog {

    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "catalog.json")

    /** Daftar dari katalog yang tersimpan (bisa dipakai saat offline). Aman dipanggil dari thread mana pun. */
    fun cached(ctx: Context): List<Wallpaper> {
        val f = cacheFile(ctx)
        if (!f.exists()) return emptyList()
        return try {
            parse(f.readText())
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Unduh katalog terbaru. HARUS dipanggil dari thread latar. true = berhasil. */
    fun refresh(ctx: Context): Boolean {
        if (!Config.isConfigured) return false
        return try {
            val conn = URL(Config.CATALOG_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            val text = try {
                if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
                conn.inputStream.bufferedReader().use { it.readText() }
            } finally {
                conn.disconnect()
            }
            parse(text) // pastikan isinya valid sebelum menimpa katalog lama
            val tmp = File(ctx.filesDir, "catalog.json.tmp")
            tmp.writeText(text)
            tmp.renameTo(cacheFile(ctx))
        } catch (e: Exception) {
            false
        }
    }

    /** Format: array `[...]` atau objek `{"wallpapers": [...]}`. Hanya alamat https yang diterima. */
    fun parse(text: String): List<Wallpaper> {
        val trimmed = text.trim()
        val arr = if (trimmed.startsWith("[")) JSONArray(trimmed)
        else JSONObject(trimmed).getJSONArray("wallpapers")

        val out = ArrayList<Wallpaper>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val url = o.optString("url")
            if (!url.startsWith("https://")) continue
            val id = o.optString("id").ifEmpty { url.substringAfterLast('/').substringBeforeLast('.') }
            out += Wallpaper(
                id = "r_$id",
                name = o.optString("name").ifEmpty { id },
                category = o.optString("category").ifEmpty { "Online" },
                url = url,
                thumbUrl = o.optString("thumb").takeIf { it.startsWith("https://") }
            )
        }
        return out
    }
}

/** Unduh gambar online sekali, lalu pakai dari cache. Panggil dari thread latar. */
object RemoteImages {
    @Throws(IOException::class)
    fun get(ctx: Context, url: String): File {
        val dir = File(ctx.cacheDir, "remote").apply { mkdirs() }
        val name = MessageDigest.getInstance("MD5").digest(url.toByteArray())
            .joinToString("") { "%02x".format(it) }
        val file = File(dir, "$name.img")
        if (file.exists() && file.length() > 0) return file

        val tmp = File(dir, "$name.${System.nanoTime()}.tmp")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 20_000
        try {
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            conn.inputStream.use { input -> FileOutputStream(tmp).use { input.copyTo(it) } }
        } catch (e: IOException) {
            tmp.delete()
            throw e
        } finally {
            conn.disconnect()
        }
        if (!tmp.renameTo(file)) {
            tmp.delete()
            if (!file.exists()) throw IOException("Gagal menyimpan gambar")
        }
        return file
    }
}
