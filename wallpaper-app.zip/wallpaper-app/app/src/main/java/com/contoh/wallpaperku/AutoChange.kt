package com.contoh.wallpaperku

import android.app.WallpaperManager
import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Ganti wallpaper otomatis secara berkala (memakai WorkManager). */
object AutoChange {
    private const val WORK_NAME = "auto_wallpaper"

    /** Jadwalkan ulang sesuai pengaturan saat ini (atau batalkan jika dimatikan). */
    fun update(ctx: Context) {
        val wm = WorkManager.getInstance(ctx.applicationContext)
        if (!Prefs.autoEnabled(ctx)) {
            wm.cancelUniqueWork(WORK_NAME)
            return
        }
        val request = PeriodicWorkRequest.Builder(
            AutoWallpaperWorker::class.java,
            Prefs.intervalHours(ctx).toLong(), TimeUnit.HOURS
        ).build()
        wm.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    /** Pilih satu wallpaper acak (selain yang terakhir) dan pasang. Panggil dari thread latar. */
    fun changeNow(ctx: Context): Boolean {
        return try {
            var pool = WallpaperData.all(ctx)
            if (Prefs.autoSource(ctx) == 1) pool = pool.filter { Prefs.isFavorite(ctx, it.id) }
            if (pool.isEmpty()) return false

            val last = Prefs.lastAutoId(ctx)
            val candidates = pool.filter { it.id != last }.ifEmpty { pool }.shuffled()

            val dm = ctx.resources.displayMetrics
            val flag = when (Prefs.autoTarget(ctx)) {
                0 -> WallpaperManager.FLAG_SYSTEM
                1 -> WallpaperManager.FLAG_LOCK
                else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            }
            // Wallpaper online bisa gagal diunduh (tanpa internet): coba sampai 3 kandidat
            for (wp in candidates.take(3)) {
                try {
                    val bmp = WallpaperRender.render(ctx, wp, dm.widthPixels, dm.heightPixels)
                    WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, flag)
                    Prefs.setLastAutoId(ctx, wp.id)
                    return true
                } catch (e: Exception) {
                    // lanjut ke kandidat berikutnya
                }
            }
            false
        } catch (e: Throwable) {
            false
        }
    }
}

class AutoWallpaperWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        AutoChange.changeNow(applicationContext)
        return Result.success()
    }
}
