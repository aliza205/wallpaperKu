package com.contoh.wallpaperku

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Menghubungkan daftar wallpaper dengan tampilan grid. */
class WallpaperAdapter(
    private var items: List<Wallpaper>,
    private val onClick: (Int) -> Unit,
    private val onFavoriteChanged: () -> Unit
) : RecyclerView.Adapter<WallpaperAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.itemImage)
        val title: TextView = view.findViewById(R.id.itemTitle)
        val fav: ImageButton = view.findViewById(R.id.itemFav)
    }

    fun submit(list: List<Wallpaper>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_wallpaper, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val ctx = holder.itemView.context
        ImageLoader.load(holder.image, item, 360, 540)
        holder.title.text = item.name
        holder.fav.setImageResource(
            if (Prefs.isFavorite(ctx, item.id)) R.drawable.ic_heart else R.drawable.ic_heart_outline
        )
        holder.itemView.setOnClickListener { onClick(holder.bindingAdapterPosition) }
        holder.fav.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_POSITION) return@setOnClickListener
            Prefs.toggleFavorite(ctx, items[pos].id)
            notifyItemChanged(pos)
            onFavoriteChanged()
        }
    }

    override fun getItemCount() = items.size
}
