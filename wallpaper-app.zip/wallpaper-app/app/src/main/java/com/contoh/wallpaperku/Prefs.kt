package com.contoh.wallpaperku

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

/** Semua pengaturan & favorit disimpan di sini (SharedPreferences). */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("wallpaperku", Context.MODE_PRIVATE)

    // ---------- Favorit ----------
    private fun favSet(c: Context): MutableSet<String> =
        HashSet(sp(c).getStringSet("fav", emptySet()) ?: emptySet())

    fun isFavorite(c: Context, id: String) = favSet(c).contains(id)

    /** Mengembalikan status favorit yang baru. */
    fun toggleFavorite(c: Context, id: String): Boolean {
        val set = favSet(c)
        val now = if (set.contains(id)) { set.remove(id); false } else { set.add(id); true }
        sp(c).edit().putStringSet("fav", set).apply()
        return now
    }

    fun removeFavorite(c: Context, id: String) {
        val set = favSet(c)
        if (set.remove(id)) sp(c).edit().putStringSet("fav", set).apply()
    }

    // ---------- Tampilan ----------
    /** 0 = ikuti sistem, 1 = terang, 2 = gelap */
    fun themeMode(c: Context) = sp(c).getInt("theme", 0)
    fun setThemeMode(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()

    fun applyTheme(c: Context) {
        AppCompatDelegate.setDefaultNightMode(
            when (themeMode(c)) {
                1 -> AppCompatDelegate.MODE_NIGHT_NO
                2 -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }

    fun columns(c: Context) = sp(c).getInt("columns", 2)
    fun setColumns(c: Context, v: Int) = sp(c).edit().putInt("columns", v).apply()

    // ---------- Ganti otomatis ----------
    fun autoEnabled(c: Context) = sp(c).getBoolean("auto", false)
    fun setAutoEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto", v).apply()

    fun intervalHours(c: Context) = sp(c).getInt("interval", 24)
    fun setIntervalHours(c: Context, v: Int) = sp(c).edit().putInt("interval", v).apply()

    /** 0 = layar utama, 1 = layar kunci, 2 = keduanya */
    fun autoTarget(c: Context) = sp(c).getInt("target", 2)
    fun setAutoTarget(c: Context, v: Int) = sp(c).edit().putInt("target", v).apply()

    /** 0 = semua wallpaper, 1 = favorit saja */
    fun autoSource(c: Context) = sp(c).getInt("source", 0)
    fun setAutoSource(c: Context, v: Int) = sp(c).edit().putInt("source", v).apply()

    fun lastAutoId(c: Context): String? = sp(c).getString("last_auto", null)
    fun setLastAutoId(c: Context, id: String) = sp(c).edit().putString("last_auto", id).apply()
}
