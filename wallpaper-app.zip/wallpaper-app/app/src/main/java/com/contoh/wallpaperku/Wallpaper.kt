package com.contoh.wallpaperku

import android.content.Context
import android.graphics.Color
import androidx.annotation.DrawableRes

const val CAT_ALL = "Semua"
const val CAT_FAV = "Favorit"
const val CAT_GALLERY = "Galeri"
const val CAT_MADE = "Buatan Saya"

/** Resep gradasi yang digambar lewat kode (linear, radial, atau sweep). */
class GradientSpec(
    val colors: IntArray,
    val angle: Int = 90,
    val type: Int = LINEAR
) {
    companion object {
        const val LINEAR = 0
        const val RADIAL = 1
        const val SWEEP = 2

        fun of(type: Int, angle: Int, vararg hex: String) =
            GradientSpec(IntArray(hex.size) { Color.parseColor(hex[it]) }, angle, type)
    }
}

/**
 * Satu data wallpaper. Sumber gambarnya salah satu dari:
 * - [imageRes]  : drawable bawaan
 * - [spec]      : gradasi yang digambar lewat kode
 * - [filePath]  : file milik pengguna (galeri / hasil buatan)
 */
data class Wallpaper(
    val id: String,
    val name: String,
    val category: String,
    @DrawableRes val imageRes: Int = 0,
    val filePath: String? = null,
    val spec: GradientSpec? = null
) {
    val isCustom: Boolean get() = filePath != null
}

/** Daftar wallpaper bawaan + milik pengguna. Tambah wallpaper bawaan di sini. */
object WallpaperData {

    private fun lin(id: String, name: String, cat: String, angle: Int, vararg hex: String) =
        Wallpaper(id, name, cat, spec = GradientSpec.of(GradientSpec.LINEAR, angle, *hex))

    private fun rad(id: String, name: String, cat: String, vararg hex: String) =
        Wallpaper(id, name, cat, spec = GradientSpec.of(GradientSpec.RADIAL, 0, *hex))

    private fun swp(id: String, name: String, cat: String, vararg hex: String) =
        Wallpaper(id, name, cat, spec = GradientSpec.of(GradientSpec.SWEEP, 0, *hex))

    val builtIn: List<Wallpaper> = listOf(
        // Alam
        Wallpaper("b_sunset", "Senja", "Alam", imageRes = R.drawable.wp_sunset),
        Wallpaper("b_ocean", "Samudra", "Alam", imageRes = R.drawable.wp_ocean),
        Wallpaper("b_forest", "Hutan", "Alam", imageRes = R.drawable.wp_forest),
        Wallpaper("b_dawn", "Fajar", "Alam", imageRes = R.drawable.wp_dawn),
        lin("g_desert", "Gurun", "Alam", 90, "#F6D365", "#FDA085"),
        lin("g_ice", "Es", "Alam", 90, "#83A4D4", "#B6FBFF"),
        lin("g_tropic", "Tropis", "Alam", 60, "#11998E", "#38EF7D"),
        // Gelap
        Wallpaper("b_galaxy", "Galaksi", "Gelap", imageRes = R.drawable.wp_galaxy),
        lin("g_midnight", "Tengah Malam", "Gelap", 90, "#0F2027", "#203A43", "#2C5364"),
        lin("g_obsidian", "Obsidian", "Gelap", 90, "#000000", "#434343"),
        lin("g_aurora", "Aurora", "Gelap", 120, "#0F0C29", "#302B63", "#24C6DC"),
        rad("g_nebula", "Nebula", "Gelap", "#C471ED", "#4B1A7A", "#12002B"),
        rad("g_moon", "Bulan", "Gelap", "#E6E6FA", "#4B5D8A", "#0B1026"),
        // Cerah
        Wallpaper("b_candy", "Permen", "Cerah", imageRes = R.drawable.wp_candy),
        lin("g_lemon", "Lemon", "Cerah", 45, "#FDFC47", "#24FE41"),
        rad("g_sun", "Matahari", "Cerah", "#FFF176", "#FF9800", "#E65100"),
        swp("g_rainbow", "Pelangi", "Cerah", "#FF512F", "#F09819", "#56CCF2", "#DD2476"),
        // Pastel
        lin("g_peach", "Persik", "Pastel", 90, "#FFECD2", "#FCB69F"),
        lin("g_mint", "Mint", "Pastel", 90, "#D4FC79", "#96E6A1"),
        lin("g_lavender", "Lavender", "Pastel", 120, "#E0C3FC", "#8EC5FC"),
        lin("g_sakura", "Sakura", "Pastel", 100, "#FBC2EB", "#A6C1EE")
    )

    fun all(ctx: Context): List<Wallpaper> = CustomStore.list(ctx) + builtIn

    fun find(ctx: Context, id: String): Wallpaper? = all(ctx).firstOrNull { it.id == id }
}
