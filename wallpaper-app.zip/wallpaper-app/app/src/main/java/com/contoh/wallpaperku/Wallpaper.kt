package com.contoh.wallpaperku

import androidx.annotation.DrawableRes

/** Satu data wallpaper: nama + gambar. */
data class Wallpaper(
    val name: String,
    @DrawableRes val imageRes: Int
)

/** Daftar wallpaper bawaan aplikasi. Tambah wallpaper baru di sini. */
object WallpaperData {
    val list = listOf(
        Wallpaper("Senja", R.drawable.wp_sunset),
        Wallpaper("Samudra", R.drawable.wp_ocean),
        Wallpaper("Hutan", R.drawable.wp_forest),
        Wallpaper("Galaksi", R.drawable.wp_galaxy),
        Wallpaper("Permen", R.drawable.wp_candy),
        Wallpaper("Fajar", R.drawable.wp_dawn)
    )
}
