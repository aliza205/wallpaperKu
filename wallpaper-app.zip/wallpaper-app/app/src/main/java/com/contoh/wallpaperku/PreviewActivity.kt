package com.contoh.wallpaperku

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** Halaman pratinjau: lihat wallpaper layar penuh, lalu pasang. */
class PreviewActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_INDEX = "index"
    }

    private lateinit var wallpaper: Wallpaper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preview)

        val index = intent.getIntExtra(EXTRA_INDEX, 0)
        wallpaper = WallpaperData.list[index]
        title = wallpaper.name

        findViewById<ImageView>(R.id.previewImage).setImageResource(wallpaper.imageRes)
        findViewById<Button>(R.id.btnSet).setOnClickListener { showChoiceDialog() }
    }

    /** Tanya pengguna: pasang di layar mana? */
    private fun showChoiceDialog() {
        val options = arrayOf("Layar utama", "Layar kunci", "Keduanya")
        AlertDialog.Builder(this)
            .setTitle("Pasang wallpaper di...")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> setWallpaper(WallpaperManager.FLAG_SYSTEM)
                    1 -> setWallpaper(WallpaperManager.FLAG_LOCK)
                    else -> setWallpaper(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
                }
            }
            .show()
    }

    private fun setWallpaper(flag: Int) {
        try {
            // Wallpaper bawaan berupa gradasi XML, jadi digambar dulu ke bitmap seukuran layar
            val drawable = ContextCompat.getDrawable(this, wallpaper.imageRes)!!
            val width = resources.displayMetrics.widthPixels
            val height = resources.displayMetrics.heightPixels
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            drawable.setBounds(0, 0, width, height)
            drawable.draw(Canvas(bitmap))
            WallpaperManager.getInstance(this).setBitmap(bitmap, null, true, flag)
            Toast.makeText(this, "Wallpaper berhasil dipasang!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal memasang wallpaper", Toast.LENGTH_SHORT).show()
        }
    }
}
