package com.contoh.wallpaperku

import android.Manifest
import android.annotation.SuppressLint
import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Pratinjau layar penuh: geser kiri/kanan untuk ganti wallpaper, atur kecerahan & blur,
 * lalu pasang / simpan / bagikan.
 */
class PreviewActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_IDS = "ids"
        private const val EXTRA_INDEX = "index"

        fun start(ctx: Context, list: List<Wallpaper>, index: Int) {
            val intent = Intent(ctx, PreviewActivity::class.java)
            intent.putExtra(EXTRA_IDS, list.map { it.id }.toTypedArray())
            intent.putExtra(EXTRA_INDEX, index)
            ctx.startActivity(intent)
        }
    }

    private lateinit var list: MutableList<Wallpaper>
    private var index = 0
    private val current: Wallpaper get() = list[index]

    private val worker = Executors.newSingleThreadExecutor()
    private var baseBitmap: Bitmap? = null
    private var baseGen = 0
    private var fxGen = 0

    private var brightness = 100   // 20..150
    private var blur = 0           // 0..3

    private lateinit var image: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var controls: View
    private lateinit var lockOverlay: View
    private lateinit var btnFav: ImageButton
    private lateinit var btnDelete: Button
    private lateinit var btnLock: Button
    private lateinit var lblBrightness: TextView
    private lateinit var lblBlur: TextView
    private lateinit var seekBrightness: SeekBar
    private lateinit var seekBlur: SeekBar
    private lateinit var detector: GestureDetector

    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) saveToGallery() else toast("Izin penyimpanan ditolak")
        }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preview)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val ids = intent.getStringArrayExtra(EXTRA_IDS) ?: emptyArray()
        val byId = WallpaperData.all(this).associateBy { it.id }
        list = ids.mapNotNull { byId[it] }.toMutableList()
        if (list.isEmpty()) {
            finish()
            return
        }
        index = intent.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, list.lastIndex)

        image = findViewById(R.id.previewImage)
        progress = findViewById(R.id.progress)
        controls = findViewById(R.id.controls)
        lockOverlay = findViewById(R.id.lockOverlay)
        btnFav = findViewById(R.id.btnFav)
        btnDelete = findViewById(R.id.btnDelete)
        btnLock = findViewById(R.id.btnLock)
        lblBrightness = findViewById(R.id.lblBrightness)
        lblBlur = findViewById(R.id.lblBlur)
        seekBrightness = findViewById(R.id.seekBrightness)
        seekBlur = findViewById(R.id.seekBlur)

        // Ketuk = sembunyikan/tampilkan kontrol, geser = ganti wallpaper
        detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val v = if (controls.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                controls.visibility = v
                btnFav.visibility = v
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dx) > 150 && abs(dx) > abs(dy) * 1.5f && abs(vx) > 600) {
                    go(if (dx < 0) 1 else -1)
                    return true
                }
                return false
            }
        })
        image.setOnTouchListener { _, ev -> detector.onTouchEvent(ev); true }

        seekBrightness.onUserChange { p ->
            brightness = p + 20
            updateLabels()
            applyPreview()
        }
        seekBlur.onUserChange { p ->
            blur = p
            updateLabels()
            applyPreview()
        }

        btnFav.setOnClickListener {
            Prefs.toggleFavorite(this, current.id)
            updateFavIcon()
        }
        findViewById<Button>(R.id.btnSet).setOnClickListener { showChoiceDialog() }
        findViewById<Button>(R.id.btnSave).setOnClickListener { onSaveClick() }
        findViewById<Button>(R.id.btnShare).setOnClickListener { share() }
        btnLock.setOnClickListener {
            val show = lockOverlay.visibility != View.VISIBLE
            lockOverlay.visibility = if (show) View.VISIBLE else View.GONE
            btnLock.text = if (show) "Sembunyikan jam" else "Simulasi kunci"
        }
        btnDelete.setOnClickListener { confirmDelete() }

        showWallpaper()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::list.isInitialized) worker.shutdownNow()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    // ---------- Tampilan ----------
    private fun go(delta: Int) {
        val n = index + delta
        if (n in list.indices) {
            index = n
            showWallpaper()
        }
    }

    private fun showWallpaper() {
        title = "${current.name} (${index + 1}/${list.size})"
        btnDelete.visibility = if (current.isCustom) View.VISIBLE else View.GONE
        updateFavIcon()

        // Efek dikembalikan ke normal setiap ganti wallpaper
        brightness = 100
        blur = 0
        seekBrightness.progress = brightness - 20
        seekBlur.progress = blur
        updateLabels()

        val myGen = ++baseGen
        val wp = current
        val dm = resources.displayMetrics
        progress.visibility = View.VISIBLE
        worker.execute {
            val base = try {
                WallpaperRender.render(applicationContext, wp, dm.widthPixels / 2, dm.heightPixels / 2)
            } catch (e: Throwable) {
                null
            }
            runOnUiThread {
                if (isDestroyed || myGen != baseGen) return@runOnUiThread
                progress.visibility = View.GONE
                if (base != null) {
                    baseBitmap = base
                    applyPreview()
                }
            }
        }
    }

    private fun updateFavIcon() {
        btnFav.setImageResource(
            if (Prefs.isFavorite(this, current.id)) R.drawable.ic_heart else R.drawable.ic_heart_outline
        )
    }

    private fun updateLabels() {
        lblBrightness.text = "Kecerahan: $brightness%"
        lblBlur.text = "Blur: " + if (blur == 0) "mati" else blur.toString()
    }

    private fun applyPreview() {
        val base = baseBitmap ?: return
        val my = ++fxGen
        val b = brightness
        val bl = blur
        worker.execute {
            val out = try {
                WallpaperRender.applyEffects(base, b, bl)
            } catch (e: Throwable) {
                null
            }
            runOnUiThread {
                if (!isDestroyed && my == fxGen && out != null) image.setImageBitmap(out)
            }
        }
    }

    // ---------- Aksi (render ukuran penuh di latar belakang) ----------
    /** Render wallpaper ukuran layar + efek, lalu jalankan [action]; hasilnya (teks) ditampilkan sebagai toast. */
    private fun runFull(action: (Bitmap) -> String) {
        val wp = current
        val b = brightness
        val bl = blur
        val dm = resources.displayMetrics
        progress.visibility = View.VISIBLE
        worker.execute {
            val msg = try {
                val bmp = WallpaperRender.applyEffects(
                    WallpaperRender.render(applicationContext, wp, dm.widthPixels, dm.heightPixels), b, bl
                )
                action(bmp)
            } catch (e: Throwable) {
                "Gagal: ${e.message ?: "terjadi kesalahan"}"
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                progress.visibility = View.GONE
                if (msg.isNotEmpty()) toast(msg)
            }
        }
    }

    private fun showChoiceDialog() {
        val options = arrayOf("Layar utama", "Layar kunci", "Keduanya")
        AlertDialog.Builder(this)
            .setTitle("Pasang wallpaper di...")
            .setItems(options) { _, which ->
                val flag = when (which) {
                    0 -> WallpaperManager.FLAG_SYSTEM
                    1 -> WallpaperManager.FLAG_LOCK
                    else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                }
                runFull { bmp ->
                    WallpaperManager.getInstance(applicationContext).setBitmap(bmp, null, true, flag)
                    "Wallpaper berhasil dipasang!"
                }
            }
            .show()
    }

    private fun onSaveClick() {
        val needsPermission = Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            saveToGallery()
        }
    }

    private fun saveToGallery() {
        val name = "WallpaperKu_${current.name.replace(Regex("[^A-Za-z0-9]+"), "_")}_${System.currentTimeMillis()}"
        runFull { bmp ->
            if (MediaSaver.save(applicationContext, bmp, name)) {
                "Disimpan di Pictures/WallpaperKu"
            } else {
                "Gagal menyimpan gambar"
            }
        }
    }

    private fun share() {
        runFull { bmp ->
            val dir = File(cacheDir, "shared").apply { mkdirs() }
            val file = File(dir, "wallpaper.jpg")
            FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            val uri = FileProvider.getUriForFile(applicationContext, "$packageName.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            runOnUiThread {
                if (!isDestroyed) startActivity(Intent.createChooser(send, "Bagikan wallpaper"))
            }
            ""
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("Hapus wallpaper ini?")
            .setMessage(current.name)
            .setPositiveButton("Hapus") { _, _ ->
                CustomStore.delete(this, current)
                list.removeAt(index)
                if (list.isEmpty()) {
                    finish()
                } else {
                    index = index.coerceAtMost(list.lastIndex)
                    showWallpaper()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
