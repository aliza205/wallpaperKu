package com.contoh.wallpaperku

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils

/** Buat wallpaper gradasi sendiri: pilih warna, jenis, dan sudut. */
class GeneratorActivity : AppCompatActivity() {

    private val colors = intArrayOf(Color.RED, Color.BLUE, Color.MAGENTA)
    private var type = GradientSpec.LINEAR
    private var angle = 90
    private var useThird = false

    private lateinit var preview: ImageView
    private lateinit var seekAngle: SeekBar
    private lateinit var lblAngle: TextView
    private lateinit var swatches: List<Button>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generator)
        title = "Buat Gradasi"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        preview = findViewById(R.id.genPreview)
        seekAngle = findViewById(R.id.seekAngle)
        lblAngle = findViewById(R.id.lblAngle)
        swatches = listOf(
            findViewById(R.id.btnColor1),
            findViewById(R.id.btnColor2),
            findViewById(R.id.btnColor3)
        )

        randomize()

        findViewById<RadioGroup>(R.id.rgType).setOnCheckedChangeListener { _, id ->
            type = when (id) {
                R.id.rbRadial -> GradientSpec.RADIAL
                R.id.rbSweep -> GradientSpec.SWEEP
                else -> GradientSpec.LINEAR
            }
            render()
        }
        seekAngle.progress = angle
        seekAngle.onUserChange { p ->
            angle = p
            render()
        }
        swatches.forEachIndexed { i, b -> b.setOnClickListener { pickColor(i) } }
        findViewById<CheckBox>(R.id.cbThird).setOnCheckedChangeListener { _, checked ->
            useThird = checked
            render()
        }
        findViewById<Button>(R.id.btnRandom).setOnClickListener {
            randomize()
            render()
        }
        findViewById<Button>(R.id.btnSaveGen).setOnClickListener { saveAndPreview() }

        render()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun spec() = GradientSpec(
        if (useThird) colors.copyOf() else colors.copyOf(2), angle, type
    )

    private fun render() {
        preview.setImageBitmap(WallpaperRender.gradient(spec(), 360, 640))
        lblAngle.text = "Sudut: $angle°" + if (type == GradientSpec.LINEAR) "" else " (hanya untuk Linear)"
        seekAngle.isEnabled = type == GradientSpec.LINEAR

        swatches.forEachIndexed { i, b ->
            b.backgroundTintList = ColorStateList.valueOf(colors[i])
            b.setTextColor(if (ColorUtils.calculateLuminance(colors[i]) > 0.5) Color.BLACK else Color.WHITE)
            b.visibility = if (i == 2 && !useThird) View.GONE else View.VISIBLE
        }
    }

    /** Warna acak yang serasi: dua warna dengan hue berdekatan, lalu satu warna aksen. */
    private fun randomize() {
        val hue = (0..359).random().toFloat()
        fun pick(h: Float) = Color.HSVToColor(
            floatArrayOf((h + 360f) % 360f, 0.55f + (0..40).random() / 100f, 0.55f + (0..45).random() / 100f)
        )
        colors[0] = pick(hue)
        colors[1] = pick(hue + 40f + (0..60).random())
        colors[2] = pick(hue + 160f + (0..60).random())
        angle = listOf(0, 45, 90, 120, 135, 180, 225, 270).random()
        seekAngle.progress = angle
    }

    private fun pickColor(i: Int) {
        val rgb = intArrayOf(Color.red(colors[i]), Color.green(colors[i]), Color.blue(colors[i]))
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), 0)
        }
        val swatch = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
            setBackgroundColor(colors[i])
        }
        layout.addView(swatch)

        val names = arrayOf("Merah", "Hijau", "Biru")
        for (k in 0..2) {
            layout.addView(TextView(this).apply {
                text = names[k]
                setPadding(0, dp(12), 0, 0)
            })
            layout.addView(SeekBar(this).apply {
                max = 255
                progress = rgb[k]
                onUserChange { p ->
                    rgb[k] = p
                    swatch.setBackgroundColor(Color.rgb(rgb[0], rgb[1], rgb[2]))
                }
            })
        }

        AlertDialog.Builder(this)
            .setTitle("Pilih warna ${i + 1}")
            .setView(layout)
            .setPositiveButton("OK") { _, _ ->
                colors[i] = Color.rgb(rgb[0], rgb[1], rgb[2])
                render()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun saveAndPreview() {
        val spec = spec()
        val dm = resources.displayMetrics
        Toast.makeText(this, "Menyimpan...", Toast.LENGTH_SHORT).show()
        Thread {
            val wp = try {
                val bmp = WallpaperRender.gradient(spec, dm.widthPixels, dm.heightPixels)
                CustomStore.saveBitmap(applicationContext, bmp, "gen")
            } catch (e: Throwable) {
                null
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (wp == null) {
                    Toast.makeText(this, "Gagal menyimpan", Toast.LENGTH_SHORT).show()
                } else {
                    PreviewActivity.start(this, listOf(wp), 0)
                    finish()
                }
            }
        }.start()
    }
}
