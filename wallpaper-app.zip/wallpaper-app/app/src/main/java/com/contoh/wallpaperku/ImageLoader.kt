package com.contoh.wallpaperku

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.util.concurrent.Executors

/** Pemuat gambar mini untuk grid (di latar belakang + cache). */
object ImageLoader {
    private val executor = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    fun load(view: ImageView, wp: Wallpaper, w: Int, h: Int) {
        if (wp.spec == null && wp.filePath == null) {
            view.tag = wp.id
            view.setImageResource(wp.imageRes)
            return
        }
        val key = "${wp.id}@${w}x$h"
        view.tag = key
        val cached = cache.get(key)
        if (cached != null) {
            view.setImageBitmap(cached)
            return
        }
        view.setImageDrawable(null)
        val ctx = view.context.applicationContext
        executor.execute {
            try {
                val bmp = WallpaperRender.render(ctx, wp, w, h)
                cache.put(key, bmp)
                main.post { if (view.tag == key) view.setImageBitmap(bmp) }
            } catch (e: Throwable) {
                // abaikan: kotak kosong lebih baik daripada aplikasi tertutup
            }
        }
    }
}
