package com.contoh.wallpaperku

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Semua urusan menggambar wallpaper menjadi bitmap + efek (kecerahan, blur). */
object WallpaperRender {

    /** Gambar wallpaper apa pun menjadi bitmap berukuran w x h. */
    fun render(ctx: Context, wp: Wallpaper, w: Int, h: Int): Bitmap {
        val spec = wp.spec
        val path = wp.filePath
        return when {
            spec != null -> gradient(spec, w, h)
            path != null -> {
                val src = decodeSampled(path, w, h)
                if (src != null) centerCrop(src, w, h) else Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            }
            else -> {
                val drawable = ContextCompat.getDrawable(ctx, wp.imageRes)!!
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                drawable.setBounds(0, 0, w, h)
                drawable.draw(Canvas(bmp))
                bmp
            }
        }
    }

    fun gradient(spec: GradientSpec, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val cx = w / 2f
        val cy = h / 2f
        paint.shader = when (spec.type) {
            GradientSpec.RADIAL ->
                RadialGradient(cx, h * 0.38f, max(w, h) * 0.8f, spec.colors, null, Shader.TileMode.CLAMP)
            GradientSpec.SWEEP ->
                // warna pertama diulang di akhir supaya putarannya mulus
                SweepGradient(cx, cy, spec.colors + spec.colors[0], null)
            else -> {
                val rad = Math.toRadians(spec.angle.toDouble())
                val dx = cos(rad).toFloat()
                val dy = sin(rad).toFloat()
                val half = abs(w / 2f * dx) + abs(h / 2f * dy)
                LinearGradient(
                    cx - dx * half, cy - dy * half, cx + dx * half, cy + dy * half,
                    spec.colors, null, Shader.TileMode.CLAMP
                )
            }
        }
        Canvas(bmp).drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        return bmp
    }

    fun decodeSampled(path: String, reqW: Int, reqH: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= reqW && bounds.outHeight / (sample * 2) >= reqH) sample *= 2
        return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    fun centerCrop(src: Bitmap, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val scale = max(w.toFloat() / src.width, h.toFloat() / src.height)
        val m = Matrix().apply {
            setScale(scale, scale)
            postTranslate((w - src.width * scale) / 2f, (h - src.height * scale) / 2f)
        }
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    /**
     * @param brightness 20..150 (100 = asli)
     * @param blur 0..3 (0 = mati)
     * Jika tidak ada efek, bitmap asli dikembalikan apa adanya.
     */
    fun applyEffects(src: Bitmap, brightness: Int, blur: Int): Bitmap {
        var bmp = src
        if (blur > 0) bmp = blurBitmap(bmp, blur + 1)
        if (brightness != 100) {
            val s = brightness / 100f
            val cm = ColorMatrix(
                floatArrayOf(
                    s, 0f, 0f, 0f, 0f,
                    0f, s, 0f, 0f, 0f,
                    0f, 0f, s, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            val out = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
            val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(cm) }
            Canvas(out).drawBitmap(bmp, 0f, 0f, paint)
            bmp = out
        }
        return bmp
    }

    /** Blur ringan: perkecil bertahap lalu perbesar bertahap (tanpa RenderScript). */
    private fun blurBitmap(src: Bitmap, halvings: Int): Bitmap {
        var cur = src
        var steps = 0
        for (i in 0 until halvings) {
            val nw = max(1, cur.width / 2)
            val nh = max(1, cur.height / 2)
            if (nw == cur.width && nh == cur.height) break
            cur = Bitmap.createScaledBitmap(cur, nw, nh, true)
            steps++
        }
        for (i in 0 until steps) {
            val last = i == steps - 1
            val nw = if (last) src.width else cur.width * 2
            val nh = if (last) src.height else cur.height * 2
            cur = Bitmap.createScaledBitmap(cur, nw, nh, true)
        }
        return cur
    }
}
