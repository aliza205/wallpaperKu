package com.contoh.wallpaperku

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout

/** FrameLayout dengan tinggi = 1,5 x lebar (rasio potret), agar kartu grid rapi di 2 atau 3 kolom. */
class RatioFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = (w * 1.5f).toInt()
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
    }
}
