package com.contoh.wallpaperku

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Halaman utama: menampilkan semua wallpaper dalam bentuk grid. */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recycler = findViewById<RecyclerView>(R.id.recyclerView)
        recycler.layoutManager = GridLayoutManager(this, 2)
        recycler.adapter = WallpaperAdapter(WallpaperData.list) { index ->
            // Saat gambar diketuk, buka halaman pratinjau
            val intent = Intent(this, PreviewActivity::class.java)
            intent.putExtra(PreviewActivity.EXTRA_INDEX, index)
            startActivity(intent)
        }
    }
}
