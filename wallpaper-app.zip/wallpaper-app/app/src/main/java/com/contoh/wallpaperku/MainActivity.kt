package com.contoh.wallpaperku

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Halaman utama: grid wallpaper + kategori, pencarian, dan favorit. */
class MainActivity : AppCompatActivity() {

    private var category = CAT_ALL
    private var query = ""
    private var all: List<Wallpaper> = emptyList()
    private var visible: List<Wallpaper> = emptyList()

    private lateinit var recycler: RecyclerView
    private lateinit var adapter: WallpaperAdapter
    private lateinit var chipRow: LinearLayout
    private lateinit var emptyView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recycler = findViewById(R.id.recyclerView)
        chipRow = findViewById(R.id.chipRow)
        emptyView = findViewById(R.id.emptyView)

        recycler.layoutManager = GridLayoutManager(this, Prefs.columns(this))
        adapter = WallpaperAdapter(
            visible,
            onClick = { index ->
                if (index >= 0) PreviewActivity.start(this, visible, index)
            },
            onFavoriteChanged = {
                // Di tab Favorit, item yang tidak difavoritkan lagi harus hilang dari daftar
                if (category == CAT_FAV) applyFilter()
            }
        )
        recycler.adapter = adapter

        // Kolom pencarian: cekung
        val search = findViewById<View>(R.id.searchField)
        Neu.basePadding(search, dp(16), dp(10), dp(16), dp(10))
        Neu.inset(search, 26, 0.7f)
        findViewById<android.widget.EditText>(R.id.searchField).doAfterTextChanged {
            query = it?.toString().orEmpty().trim()
            applyFilter()
        }

        // Tombol menu
        val more = findViewById<ImageButton>(R.id.btnMore)
        Neu.pressable(more, 0, 0.8f, circle = true)
        more.setOnClickListener { showMenu(it) }

        refreshCatalog(manual = false)
    }

    override fun onResume() {
        super.onResume()
        // Pengaturan / favorit / koleksi bisa berubah saat halaman lain dibuka
        (recycler.layoutManager as GridLayoutManager).spanCount = Prefs.columns(this)
        reload()
    }

    // ---------- Menu ----------
    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.main_menu, popup.menu)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_random -> {
                    val pool = if (visible.isNotEmpty()) visible else all
                    if (pool.isNotEmpty()) PreviewActivity.start(this, pool, pool.indices.random())
                    true
                }
                R.id.action_refresh -> {
                    refreshCatalog(manual = true)
                    true
                }
                R.id.action_create -> {
                    startActivity(Intent(this, GeneratorActivity::class.java))
                    true
                }
                R.id.action_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    /** Ambil katalog online terbaru di latar belakang, lalu segarkan grid. */
    private fun refreshCatalog(manual: Boolean) {
        if (!Config.isConfigured) {
            if (manual) {
                Toast.makeText(this, "Katalog online belum diatur (isi CATALOG_URL di Config.kt)", Toast.LENGTH_LONG).show()
            }
            return
        }
        Thread {
            val ok = RemoteCatalog.refresh(applicationContext)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (ok) reload()
                if (manual) {
                    Toast.makeText(
                        this,
                        if (ok) "Katalog diperbarui" else "Gagal memuat katalog. Cek koneksi internet.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }.start()
    }

    // ---------- Data ----------
    private fun reload() {
        all = WallpaperData.all(this)
        buildChips()
        applyFilter()
    }

    private fun applyFilter() {
        visible = all.filter { wp ->
            val inCategory = when (category) {
                CAT_ALL -> true
                CAT_FAV -> Prefs.isFavorite(this, wp.id)
                else -> wp.category == category
            }
            inCategory && (query.isEmpty() || wp.name.contains(query, ignoreCase = true))
        }
        adapter.submit(visible)

        emptyView.visibility = if (visible.isEmpty()) View.VISIBLE else View.GONE
        emptyView.text = when {
            query.isNotEmpty() -> "Tidak ada wallpaper bernama \"$query\""
            category == CAT_FAV -> "Belum ada favorit.\nKetuk ikon hati pada wallpaper."
            else -> "Belum ada wallpaper di kategori ini."
        }
    }

    private fun buildChips() {
        val cats = mutableListOf(CAT_ALL, CAT_FAV)
        // Kategori bawaan + kategori dari katalog online (digabung tanpa duplikat)
        cats += (WallpaperData.builtIn + all.filter { it.isRemote }).map { it.category }.distinct()
        if (all.any { it.category == CAT_MADE }) cats += CAT_MADE
        if (category !in cats) category = CAT_ALL

        val accent = ContextCompat.getColor(this, R.color.neu_accent)
        val normal = ContextCompat.getColor(this, R.color.neu_text_sub)

        chipRow.removeAllViews()
        for (cat in cats) {
            val chip = TextView(this).apply {
                text = if (cat == CAT_FAV) "♥ $cat" else cat
                textSize = 13f
                setPadding(dp(12), dp(4), dp(12), dp(4))
                isClickable = true
                isSelected = cat == category
                setTextColor(if (isSelected) accent else normal)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                setOnClickListener {
                    category = cat
                    buildChips()
                    applyFilter()
                }
            }
            Neu.pressable(chip, 22, 0.6f)
            chipRow.addView(chip)
        }
    }
}
