package com.contoh.wallpaperku

import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Halaman utama: grid wallpaper + kategori, pencarian, dan favorit. */
class MainActivity : AppCompatActivity() {

    private var category = CAT_ALL
    private var query = ""
    private var all: List<Wallpaper> = emptyList()
    private var visible: List<Wallpaper> = emptyList()

    private lateinit var recycler: RecyclerView
    private lateinit var adapter: WallpaperAdapter
    private lateinit var chipRow: LinearLayout
    private lateinit var emptyView: TextView

    private val pickImages =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            if (uris.isNotEmpty()) importImages(uris)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recycler = findViewById(R.id.recyclerView)
        chipRow = findViewById(R.id.chipRow)
        emptyView = findViewById(R.id.emptyView)

        recycler.layoutManager = GridLayoutManager(this, Prefs.columns(this))
        adapter = WallpaperAdapter(
            visible,
            onClick = { index ->
                if (index >= 0) PreviewActivity.start(this, visible, index)
            },
            onFavoriteChanged = {
                // Di tab Favorit, item yang tidak difavoritkan lagi harus hilang dari daftar
                if (category == CAT_FAV) applyFilter()
            }
        )
        recycler.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        // Pengaturan / favorit / koleksi bisa berubah saat halaman lain dibuka
        (recycler.layoutManager as GridLayoutManager).spanCount = Prefs.columns(this)
        reload()
    }

    // ---------- Menu ----------
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)

        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView
        searchView.queryHint = "Cari wallpaper..."
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(q: String?) = false
            override fun onQueryTextChange(newText: String?): Boolean {
                query = newText.orEmpty().trim()
                applyFilter()
                return true
            }
        })
        searchItem.setOnActionExpandListener(object : MenuItem.OnActionExpandListener {
            override fun onMenuItemActionExpand(item: MenuItem) = true
            override fun onMenuItemActionCollapse(item: MenuItem): Boolean {
                query = ""
                applyFilter()
                return true
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_random -> {
            val pool = if (visible.isNotEmpty()) visible else all
            if (pool.isNotEmpty()) PreviewActivity.start(this, pool, pool.indices.random())
            true
        }
        R.id.action_add -> {
            pickImages.launch("image/*")
            true
        }
        R.id.action_create -> {
            startActivity(Intent(this, GeneratorActivity::class.java))
            true
        }
        R.id.action_settings -> {
            startActivity(Intent(this, SettingsActivity::class.java))
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

    // ---------- Data ----------
    private fun reload() {
        all = WallpaperData.all(this)
        buildChips()
        applyFilter()
    }

    private fun applyFilter() {
        visible = all.filter { wp ->
            val inCategory = when (category) {
                CAT_ALL -> true
                CAT_FAV -> Prefs.isFavorite(this, wp.id)
                else -> wp.category == category
            }
            inCategory && (query.isEmpty() || wp.name.contains(query, ignoreCase = true))
        }
        adapter.submit(visible)

        emptyView.visibility = if (visible.isEmpty()) View.VISIBLE else View.GONE
        emptyView.text = when {
            query.isNotEmpty() -> "Tidak ada wallpaper bernama \"$query\""
            category == CAT_FAV -> "Belum ada favorit.\nKetuk ikon hati pada wallpaper."
            else -> "Belum ada wallpaper di kategori ini."
        }
    }

    private fun buildChips() {
        val cats = mutableListOf(CAT_ALL, CAT_FAV)
        cats += WallpaperData.builtIn.map { it.category }.distinct()
        if (all.any { it.category == CAT_GALLERY }) cats += CAT_GALLERY
        if (all.any { it.category == CAT_MADE }) cats += CAT_MADE
        if (category !in cats) category = CAT_ALL

        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.textColorPrimary, tv, true)
        val normalText = if (tv.resourceId != 0) ContextCompat.getColor(this, tv.resourceId) else tv.data

        chipRow.removeAllViews()
        for (cat in cats) {
            val chip = TextView(this).apply {
                text = if (cat == CAT_FAV) "♥ $cat" else cat
                setPadding(dp(14), dp(7), dp(14), dp(7))
                background = ContextCompat.getDrawable(this@MainActivity, R.drawable.bg_chip)
                isSelected = cat == category
                setTextColor(if (isSelected) 0xFFFFFFFF.toInt() else normalText)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(8) }
                setOnClickListener {
                    category = cat
                    buildChips()
                    applyFilter()
                }
            }
            chipRow.addView(chip)
        }
    }

    private fun importImages(uris: List<android.net.Uri>) {
        Toast.makeText(this, "Mengimpor ${uris.size} gambar...", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = uris.count { CustomStore.importUri(applicationContext, it) }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                val msg = if (ok > 0) "$ok gambar ditambahkan ke Galeri" else "Gagal mengimpor gambar"
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                if (ok > 0) category = CAT_GALLERY
                reload()
            }
        }.start()
    }
}
