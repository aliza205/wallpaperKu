package com.contoh.wallpaperku

import android.app.Application

/** Dijalankan sekali saat aplikasi dibuka: terapkan tema pilihan pengguna. */
class WallpaperApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.applyTheme(this)
    }
}
