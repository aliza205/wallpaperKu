package com.contoh.wallpaperku

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

/**
 * Wallpaper milik pengguna, disimpan sebagai file JPEG di penyimpanan internal aplikasi.
 * Awalan nama file: "gal_" = dari galeri, "gen_" = hasil Buat Gradasi.
 */
object CustomStore {

    private fun dir(ctx: Context): File = File(ctx.filesDir, "custom").apply { mkdirs() }

    fun list(ctx: Context): List<Wallpaper> {
        val fmt = SimpleDateFormat("d MMM, HH:mm", Locale("id"))
        val files = dir(ctx).listFiles { f -> f.isFile && f.extension == "jpg" } ?: return emptyList()
        return files.sortedByDescending { it.lastModified() }.map { f ->
            val generated = f.name.startsWith("gen_")
            Wallpaper(
                id = f.name,
                name = (if (generated) "Gradasi " else "Foto ") + fmt.format(Date(f.lastModified())),
                category = if (generated) CAT_MADE else CAT_GALLERY,
                filePath = f.absolutePath
            )
        }
    }

    private fun newFile(ctx: Context, prefix: String): File =
        File(dir(ctx), "${prefix}_${System.currentTimeMillis()}_${(0..9999).random()}.jpg")

    /** Simpan bitmap sebagai wallpaper milik pengguna. */
    fun saveBitmap(ctx: Context, bmp: Bitmap, prefix: String): Wallpaper? {
        return try {
            val f = newFile(ctx, prefix)
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            list(ctx).firstOrNull { it.id == f.name }
        } catch (e: Exception) {
            null
        }
    }

    /** Salin satu gambar dari galeri ke penyimpanan aplikasi (diperkecil + dirotasi sesuai EXIF). */
    fun importUri(ctx: Context, uri: Uri): Boolean {
        return try {
            val resolver = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0) return false

            val maxSide = 2560
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false

            val degrees = try {
                resolver.openInputStream(uri)?.use { stream ->
                    when (ExifInterface(stream).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
            } catch (e: Exception) {
                0f
            }
            if (degrees != 0f) {
                val m = Matrix().apply { postRotate(degrees) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }

            FileOutputStream(newFile(ctx, "gal")).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun delete(ctx: Context, wp: Wallpaper) {
        wp.filePath?.let { File(it).delete() }
        Prefs.removeFavorite(ctx, wp.id)
    }
}
