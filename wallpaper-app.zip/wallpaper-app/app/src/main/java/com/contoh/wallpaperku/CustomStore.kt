package com.contoh.wallpaperku

import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Wallpaper buatan pengguna (hasil Buat Gradasi), disimpan sebagai file JPEG
 * di penyimpanan internal aplikasi.
 */
object CustomStore {

    private fun dir(ctx: Context): File = File(ctx.filesDir, "custom").apply { mkdirs() }

    fun list(ctx: Context): List<Wallpaper> {
        val fmt = SimpleDateFormat("d MMM, HH:mm", Locale("id"))
        val files = dir(ctx).listFiles { f -> f.isFile && f.extension == "jpg" } ?: return emptyList()
        return files.sortedByDescending { it.lastModified() }.map { f ->
            Wallpaper(
                id = f.name,
                // file "gal_" berasal dari versi lama aplikasi (impor galeri), tetap ditampilkan
                name = (if (f.name.startsWith("gal_")) "Foto " else "Gradasi ") + fmt.format(Date(f.lastModified())),
                category = CAT_MADE,
                filePath = f.absolutePath
            )
        }
    }

    /** Simpan bitmap sebagai wallpaper milik pengguna. */
    fun saveBitmap(ctx: Context, bmp: Bitmap, prefix: String): Wallpaper? {
        return try {
            val f = File(dir(ctx), "${prefix}_${System.currentTimeMillis()}_${(0..9999).random()}.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            list(ctx).firstOrNull { it.id == f.name }
        } catch (e: Exception) {
            null
        }
    }

    fun delete(ctx: Context, wp: Wallpaper) {
        wp.filePath?.let { File(it).delete() }
        Prefs.removeFavorite(ctx, wp.id)
    }
}
