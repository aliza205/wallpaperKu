# WallpaperKu

Aplikasi wallpaper Android sederhana (Kotlin).

## Fitur
- Daftar wallpaper dalam bentuk grid
- Pratinjau layar penuh
- Pasang ke layar utama, layar kunci, atau keduanya

## Cara menjalankan
1. Install **Android Studio** (versi terbaru).
2. Pilih **Open** lalu pilih folder `wallpaper-app` ini.
3. Tunggu proses *Gradle Sync* selesai.
4. Sambungkan HP (aktifkan USB debugging) atau buat emulator.
5. Klik tombol **Run** (segitiga hijau).

## Struktur kode (ringkas)
| File | Fungsi |
|------|--------|
| `Wallpaper.kt` | Data wallpaper + daftar wallpaper |
| `MainActivity.kt` | Halaman grid |
| `WallpaperAdapter.kt` | Mengisi grid dengan data |
| `PreviewActivity.kt` | Pratinjau + tombol pasang wallpaper |

## Menambah wallpaper sendiri
1. Salin gambar (jpg/png) ke `app/src/main/res/drawable/`, misalnya `wp_pantai.jpg`.
   Gunakan huruf kecil dan tanpa spasi.
2. Tambahkan satu baris di `Wallpaper.kt`:
   ```kotlin
   Wallpaper("Pantai", R.drawable.wp_pantai),
   ```
3. Jalankan ulang aplikasi.

Wallpaper bawaan berupa gradasi warna (tanpa file gambar), jadi proyek langsung bisa dijalankan.
