# WallpaperKu

Aplikasi wallpaper Android (Kotlin).

## Fitur
**Menjelajah**
- Grid wallpaper (2 atau 3 kolom) dengan sudut membulat
- Filter kategori: Alam, Gelap, Cerah, Pastel, Galeri, Buatan Saya
- Pencarian berdasarkan nama
- Favorit (ikon hati) + tab Favorit
- Wallpaper acak
- 21 wallpaper bawaan (gradasi linear, radial, dan sweep)

**Pratinjau**
- Geser kiri/kanan untuk ganti wallpaper, ketuk untuk sembunyikan kontrol
- Atur kecerahan dan blur sebelum dipasang
- Simulasi layar kunci (jam & tanggal)
- Pasang ke layar utama, layar kunci, atau keduanya
- Simpan ke galeri HP (Pictures/WallpaperKu) dan bagikan ke aplikasi lain

**Koleksi sendiri**
- Tambah foto dari galeri HP (bisa banyak sekaligus)
- Buat gradasi sendiri (linear/radial/sweep, 2–3 warna, sudut, acak warna)
- Hapus wallpaper milik sendiri

**Pengaturan**
- Tema: ikuti sistem / terang / gelap
- Jumlah kolom grid
- Ganti wallpaper otomatis (tiap 1/3/6/12/24 jam; layar utama/kunci/keduanya; dari semua atau favorit saja)

## Cara menjalankan
1. Install **Android Studio** (versi terbaru).
2. Pilih **Open** lalu pilih folder `wallpaper-app` ini.
3. Tunggu proses *Gradle Sync* selesai.
4. Sambungkan HP (aktifkan USB debugging) atau buat emulator.
5. Klik tombol **Run** (segitiga hijau).

Atau unggah ke GitHub: workflow di `.github/workflows/build.yml` akan membuat APK otomatis.

## Struktur kode (ringkas)
| File | Fungsi |
|------|--------|
| `Wallpaper.kt` | Data wallpaper + daftar wallpaper bawaan |
| `Prefs.kt` | Favorit & pengaturan (SharedPreferences) |
| `CustomStore.kt` | Wallpaper milik pengguna (impor galeri, simpan, hapus) |
| `WallpaperRender.kt` | Menggambar wallpaper ke bitmap + efek kecerahan/blur |
| `ImageLoader.kt` | Pemuat gambar mini untuk grid (latar belakang + cache) |
| `MainActivity.kt` / `WallpaperAdapter.kt` | Halaman grid, kategori, pencarian |
| `PreviewActivity.kt` | Pratinjau, efek, pasang, simpan, bagikan |
| `GeneratorActivity.kt` | Buat gradasi sendiri |
| `SettingsActivity.kt` | Pengaturan |
| `AutoChange.kt` | Ganti wallpaper otomatis (WorkManager) |
| `Utils.kt` | Fungsi bantu + simpan ke galeri |

## Menambah wallpaper bawaan
**Gradasi lewat kode** — tambahkan satu baris di `WallpaperData.builtIn` (`Wallpaper.kt`):
```kotlin
lin("g_senja2", "Senja 2", "Alam", 90, "#FF9966", "#FF5E62"),
```
**Gambar sendiri** — salin gambar (jpg/png) ke `app/src/main/res/drawable/`, misalnya `wp_pantai.jpg`
(huruf kecil, tanpa spasi), lalu tambahkan:
```kotlin
Wallpaper("b_pantai", "Pantai", "Alam", imageRes = R.drawable.wp_pantai),
```
`id` harus unik dan jangan diubah setelah dirilis (dipakai untuk menyimpan favorit).

## Catatan
- Ganti otomatis memakai WorkManager; Android menjalankannya kira-kira sesuai interval, bukan tepat waktu.
- Wallpaper dari galeri disalin ke penyimpanan aplikasi, jadi tetap ada walau foto aslinya dihapus.
