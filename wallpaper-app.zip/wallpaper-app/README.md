# WallpaperKu

Aplikasi wallpaper Android (Kotlin).

## Fitur
**Menjelajah**
- Grid wallpaper (2 atau 3 kolom) dengan sudut membulat
- Filter kategori: Alam, Gelap, Cerah, Pastel, Buatan Saya
- Pencarian berdasarkan nama
- Favorit (ikon hati) + tab Favorit
- Wallpaper acak
- 21 wallpaper bawaan (gradasi linear, radial, dan sweep)

**Pratinjau**
- Geser kiri/kanan untuk ganti wallpaper, ketuk untuk sembunyikan kontrol
- Simulasi layar kunci (jam & tanggal)
- Pasang ke layar utama, layar kunci, atau keduanya
- Simpan ke galeri HP (Pictures/WallpaperKu) dan bagikan ke aplikasi lain

**Tampilan**
- Tema minimalis modern bergaya neumorphism (permukaan timbul/cekung dengan bayangan lembut), mode terang dan gelap

**Koleksi sendiri**
- Buat gradasi sendiri (linear/radial/sweep, 2–3 warna, sudut, acak warna)
- Hapus wallpaper milik sendiri

**Katalog online** (wallpaper tidak perlu dimasukkan ke aplikasi)
- Gambar disimpan di internet (mis. repo GitHub) dan daftarnya di `catalog.json`
- Aplikasi mengambil daftar saat dibuka, memakai gambar kecil di grid, dan mengunduh gambar penuh hanya saat dibuka
- Gambar yang sudah diunduh disimpan, katalog tetap tampil saat offline
- Menambah wallpaper = unggah gambar + jalankan skrip, tanpa rilis ulang aplikasi
- Cara pakai: lihat `katalog-online/README.md`, lalu isi `CATALOG_URL` di `Config.kt`

**Pengaturan**
- Tema: ikuti sistem / terang / gelap
- Jumlah kolom grid
- Ganti wallpaper otomatis (tiap 1/3/6/12/24 jam; layar utama/kunci/keduanya; dari semua atau favorit saja)

## Cara menjalankan
1. Install **Android Studio** (versi terbaru).
2. Pilih **Open** lalu pilih folder `wallpaper-app` ini.
3. Tunggu proses *Gradle Sync* selesai.
4. Sambungkan HP (aktifkan USB debugging) atau buat emulator.
5. Klik tombol **Run** (segitiga hijau).

Atau unggah ke GitHub: workflow di `.github/workflows/build.yml` akan membuat APK otomatis.

## Struktur kode (ringkas)
| File | Fungsi |
|------|--------|
| `Wallpaper.kt` | Data wallpaper + daftar wallpaper bawaan |
| `Prefs.kt` | Favorit & pengaturan (SharedPreferences) |
| `CustomStore.kt` | Wallpaper buatan pengguna (simpan, hapus) |
| `Neu.kt` | Gaya neumorphism: bayangan timbul/cekung + pembantu untuk view |
| `WallpaperRender.kt` | Menggambar wallpaper ke bitmap |
| `ImageLoader.kt` | Pemuat gambar mini untuk grid (latar belakang + cache) |
| `MainActivity.kt` / `WallpaperAdapter.kt` | Halaman grid, kategori, pencarian |
| `PreviewActivity.kt` | Pratinjau, efek, pasang, simpan, bagikan |
| `GeneratorActivity.kt` | Buat gradasi sendiri |
| `SettingsActivity.kt` | Pengaturan |
| `Config.kt` | Alamat katalog online (`CATALOG_URL`) |
| `RemoteCatalog.kt` | Ambil katalog online + unduh gambar dengan cache |
| `AutoChange.kt` | Ganti wallpaper otomatis (WorkManager) |
| `Utils.kt` | Fungsi bantu + simpan ke galeri |

## Menambah wallpaper bawaan
**Gradasi lewat kode** — tambahkan satu baris di `WallpaperData.builtIn` (`Wallpaper.kt`):
```kotlin
lin("g_senja2", "Senja 2", "Alam", 90, "#FF9966", "#FF5E62"),
```
**Gambar sendiri** — salin gambar (jpg/png) ke `app/src/main/res/drawable/`, misalnya `wp_pantai.jpg`
(huruf kecil, tanpa spasi), lalu tambahkan:
```kotlin
Wallpaper("b_pantai", "Pantai", "Alam", imageRes = R.drawable.wp_pantai),
```
`id` harus unik dan jangan diubah setelah dirilis (dipakai untuk menyimpan favorit).

## Catatan
- Katalog online hanya menerima alamat `https://`. Selama `CATALOG_URL` masih berisi `USERNAME`, fitur online mati.
- Ganti otomatis memakai WorkManager; Android menjalankannya kira-kira sesuai interval, bukan tepat waktu.
- Warna tema ada di `res/values/colors.xml` (terang) dan `res/values-night/colors.xml` (gelap); ubah `neu_bg`, `neu_light`, `neu_dark`, `neu_accent` untuk mengganti nuansa.
